$(document).ready(function() {
	$(".photo-user").click(function() {
		$(".login-form").toggle("slow");
	});
});